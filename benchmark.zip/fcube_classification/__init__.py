from flgo.benchmark.fcube_classification.model import lr

default_model = lr